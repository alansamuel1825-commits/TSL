export default function AskPage() {
  return (
    <main className="min-h-screen bg-white px-6 py-16">
      <div className="mx-auto max-w-5xl">
        <p className="text-sm font-semibold uppercase tracking-[0.2em] text-slate-500">
          TSL Alumni Connect
        </p>

        <h1 className="mt-4 text-5xl font-bold tracking-tight">
          Ask an Alumni
        </h1>

        <p className="mt-5 max-w-2xl text-lg leading-8 text-slate-600">
          Have a question about university, careers, industries,
          projects or life after TSL? Ask someone who has already
          experienced it.
        </p>

        <div className="mt-12 rounded-3xl border border-slate-200 p-8">
          <h2 className="text-xl font-semibold">
            What would you like to ask?
          </h2>

          <textarea
            placeholder="Write your question..."
            className="mt-5 min-h-40 w-full rounded-2xl border border-slate-300 p-4 outline-none focus:border-slate-500"
          />

          <button className="mt-5 rounded-full bg-slate-900 px-6 py-3 font-medium text-white hover:bg-slate-800">
            Submit Question
          </button>
        </div>
      </div>
    </main>
  );
}