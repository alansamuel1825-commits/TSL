"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

import { useAuth } from "@/lib/auth/useAuth";

import {
  createConversation,
  getConversationsForUser,
  getUserProfile,
  sendMessage,
  getConversationMessages,
  type Conversation,
  type ChatMessage,
} from "@/lib/firebase/firestore";

type OtherUser = {
  name?: string;
  role?: string;
};

export default function MessagesPage() {
  const router = useRouter();
  const { user, loading } = useAuth();

  const [conversations, setConversations] = useState<
    Conversation[]
  >([]);

  const [selectedConversation, setSelectedConversation] =
    useState<Conversation | null>(null);

  const [messages, setMessages] = useState<ChatMessage[]>([]);

  const [otherUser, setOtherUser] =
    useState<OtherUser | null>(null);

  const [loadingMessages, setLoadingMessages] =
    useState(false);

  const [messageText, setMessageText] = useState("");

  const [sending, setSending] = useState(false);

  const [error, setError] = useState("");

  // =========================================================
  // LOAD CONVERSATIONS
  // =========================================================

  useEffect(() => {
    if (loading) return;

    if (!user) {
      router.replace("/login");
      return;
    }

    const currentUser = user;

    async function loadConversations() {
      try {
        const results =
          await getConversationsForUser(
            currentUser.uid
          );

        setConversations(results);
      } catch (err) {
        console.error(err);
        setError(
          "Unable to load your conversations."
        );
      }
    }

    loadConversations();
  }, [user, loading, router]);

  // =========================================================
  // LOAD SELECTED CONVERSATION
  // =========================================================

  useEffect(() => {
  if (!selectedConversation || !user) {
    return;
  }

  const currentConversation = selectedConversation;
  const currentUser = user;

  async function loadMessages() {
      setLoadingMessages(true);
      setError("");

      try {
        const results =
          await getConversationMessages(
            currentConversation.id
          );

        setMessages(results);

        const otherUserId =
          currentConversation.studentId ===
          currentUser.uid
            ? currentConversation.alumniId
            : currentConversation.studentId;

        const profile =
          await getUserProfile(otherUserId);

        setOtherUser(
          profile
            ? {
                name: profile.displayName,
                role: profile.role,
              }
            : null
        );
      } catch (err) {
        console.error(err);
        setError(
          "Unable to load this conversation."
        );
      } finally {
        setLoadingMessages(false);
      }
    }

    loadMessages();
  }, [selectedConversation, user]);

  // =========================================================
  // SEND MESSAGE
  // =========================================================

  async function handleSendMessage() {
    if (
      !user ||
      !selectedConversation ||
      !messageText.trim()
    ) {
      return;
    }

    setSending(true);
    setError("");

    const text = messageText.trim();

    try {
      await sendMessage(
        selectedConversation.id,
        user.uid,
        text
      );

      setMessageText("");

      const updated =
        await getConversationMessages(
          selectedConversation.id
        );

      setMessages(updated);

      setConversations((current) =>
        current.map((conversation) =>
          conversation.id ===
          selectedConversation.id
            ? {
                ...conversation,
                lastMessage: text,
              }
            : conversation
        )
      );
    } catch (err) {
      console.error(err);

      setError(
        "Unable to send your message."
      );
    } finally {
      setSending(false);
    }
  }

  // =========================================================
  // ENTER TO SEND
  // =========================================================

  function handleKeyDown(
    event: React.KeyboardEvent<HTMLTextAreaElement>
  ) {
    if (
      event.key === "Enter" &&
      !event.shiftKey
    ) {
      event.preventDefault();
      handleSendMessage();
    }
  }

  // =========================================================
  // LOADING
  // =========================================================

  if (loading) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-slate-50">
        <p className="text-slate-500">
          Loading messages...
        </p>
      </main>
    );
  }

  // =========================================================
  // UI
  // =========================================================

  return (
    <main className="min-h-screen bg-slate-50">

      <div className="mx-auto flex min-h-screen max-w-7xl">

        {/* =================================================
            SIDEBAR
        ================================================= */}

        <aside className="hidden w-80 shrink-0 border-r border-slate-200 bg-white md:block">

          <div className="border-b border-slate-200 p-6">

            <button
              onClick={() =>
                router.push("/alumni")
              }
              className="text-sm font-semibold text-slate-500 hover:text-slate-950"
            >
              ← Alumni
            </button>

            <h1 className="mt-5 text-2xl font-bold text-slate-950">
              Messages
            </h1>

            <p className="mt-1 text-sm text-slate-500">
              Your TSL conversations
            </p>

          </div>

          <div className="divide-y divide-slate-100">

            {conversations.length === 0 ? (
              <div className="p-8 text-center">
                <p className="text-sm font-medium text-slate-700">
                  No conversations yet
                </p>

                <p className="mt-2 text-xs leading-5 text-slate-400">
                  Accepted mentorship connections
                  will appear here.
                </p>
              </div>
            ) : (
              conversations.map(
                (conversation) => {

                  const otherId =
                    conversation.studentId ===
                    user?.uid
                      ? conversation.alumniId
                      : conversation.studentId;

                  return (
                    <button
                      key={conversation.id}
                      onClick={() =>
                        setSelectedConversation(
                          conversation
                        )
                      }
                      className={`w-full p-5 text-left transition ${
                        selectedConversation?.id ===
                        conversation.id
                          ? "bg-slate-100"
                          : "hover:bg-slate-50"
                      }`}
                    >

                      <div className="flex items-center gap-3">

                        <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-slate-900 font-semibold text-white">
                          ?
                        </div>

                        <div className="min-w-0">

                          <p className="truncate text-sm font-semibold text-slate-900">
                            TSL connection
                          </p>

                          <p className="mt-1 truncate text-xs text-slate-500">
                            {conversation.lastMessage ||
                              "No messages yet"}
                          </p>

                        </div>

                      </div>

                    </button>
                  );
                }
              )
            )}

          </div>

        </aside>

        {/* =================================================
            CHAT
        ================================================= */}

        <section className="flex min-w-0 flex-1 flex-col">

          {!selectedConversation ? (

            <div className="flex flex-1 items-center justify-center p-8">

              <div className="max-w-md text-center">

                <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-3xl bg-white text-2xl shadow-sm">
                  💬
                </div>

                <h2 className="mt-5 text-2xl font-bold text-slate-950">
                  Your conversations
                </h2>

                <p className="mt-3 text-sm leading-6 text-slate-500">
                  Select a conversation from the
                  sidebar to start chatting with a
                  member of the TSL alumni community.
                </p>

              </div>

            </div>

          ) : (

            <>

              {/* CHAT HEADER */}

              <header className="border-b border-slate-200 bg-white px-6 py-5">

                <div className="flex items-center gap-4">

                  <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-slate-900 font-bold text-white">
                    {otherUser?.name
                      ?.charAt(0)
                      .toUpperCase() || "?"}
                  </div>

                  <div>

                    <h2 className="font-bold text-slate-950">
                      {otherUser?.name ||
                        "TSL Alumni"}
                    </h2>

                    <p className="text-xs text-slate-500">
                      {otherUser?.role ||
                        "TSL community member"}
                    </p>

                  </div>

                </div>

              </header>

              {/* MESSAGES */}

              <div className="flex-1 overflow-y-auto px-6 py-8">

                {loadingMessages ? (

                  <div className="flex h-full items-center justify-center">
                    <p className="text-sm text-slate-400">
                      Loading conversation...
                    </p>
                  </div>

                ) : messages.length === 0 ? (

                  <div className="flex h-full items-center justify-center">

                    <div className="text-center">

                      <p className="font-semibold text-slate-800">
                        Start the conversation
                      </p>

                      <p className="mt-2 text-sm text-slate-500">
                        Introduce yourself and
                        say hello.
                      </p>

                    </div>

                  </div>

                ) : (

                  <div className="mx-auto max-w-3xl space-y-4">

                    {messages.map((message) => {

                      const isMine =
                        message.senderId ===
                        user?.uid;

                      return (
                        <div
                          key={message.id}
                          className={`flex ${
                            isMine
                              ? "justify-end"
                              : "justify-start"
                          }`}
                        >

                          <div
                            className={`max-w-[80%] rounded-3xl px-5 py-3 text-sm leading-6 ${
                              isMine
                                ? "bg-slate-950 text-white"
                                : "bg-white text-slate-800 shadow-sm"
                            }`}
                          >
                            {message.text}
                          </div>

                        </div>
                      );
                    })}

                  </div>

                )}

              </div>

              {/* ERROR */}

              {error && (
                <div className="px-6">
                  <div className="mx-auto max-w-3xl rounded-2xl bg-red-50 p-3 text-sm text-red-700">
                    {error}
                  </div>
                </div>
              )}

              {/* COMPOSER */}

              <div className="border-t border-slate-200 bg-white p-5">

                <div className="mx-auto flex max-w-3xl items-end gap-3">

                  <textarea
                    value={messageText}
                    onChange={(event) =>
                      setMessageText(
                        event.target.value
                      )
                    }
                    onKeyDown={handleKeyDown}
                    maxLength={2000}
                    rows={1}
                    placeholder="Write a message..."
                    className="max-h-32 min-h-[48px] flex-1 resize-none rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none transition focus:border-slate-900 focus:bg-white"
                  />

                  <button
                    onClick={handleSendMessage}
                    disabled={
                      sending ||
                      !messageText.trim()
                    }
                    className="rounded-2xl bg-slate-950 px-5 py-3 text-sm font-semibold text-white transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-40"
                  >
                    {sending
                      ? "..."
                      : "Send"}
                  </button>

                </div>

                <p className="mx-auto mt-2 max-w-3xl text-xs text-slate-400">
                  Enter to send · Shift + Enter
                  for a new line
                </p>

              </div>

            </>

          )}

        </section>

      </div>

    </main>
  );
}