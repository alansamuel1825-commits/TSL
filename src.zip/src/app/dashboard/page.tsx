"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";

import { useAuth } from "@/lib/auth/useAuth";
import { logOut } from "@/lib/firebase/auth";

export default function DashboardPage() {
  const router = useRouter();
  const { user, loading } = useAuth();

  useEffect(() => {
    if (!loading && !user) {
      router.replace("/login");
    }
  }, [loading, user, router]);

  if (loading) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-slate-50">
        <p className="text-slate-500">
          Loading your TSL account...
        </p>
      </main>
    );
  }

  if (!user) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-slate-50">
        <p className="text-slate-500">
          Redirecting to sign in...
        </p>
      </main>
    );
  }

  async function handleSignOut() {
    await logOut();
    router.replace("/login");
  }

  return (
    <main className="min-h-screen bg-slate-50 px-6 py-16">
      <div className="mx-auto max-w-5xl">

        <div className="mb-8">
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-slate-500">
            TSL Alumni Connect
          </p>

          <h1 className="mt-3 text-4xl font-bold tracking-tight">
            Welcome 👋
          </h1>

          <p className="mt-3 text-slate-600">
            Your TSL Connect account is working.
          </p>
        </div>

        <div className="rounded-3xl border border-slate-200 bg-white p-8 shadow-sm">

          <p className="text-sm text-slate-500">
            Signed in as
          </p>

          <p className="mt-2 text-lg font-semibold">
            {user.email ?? "Google account"}
          </p>

          <div className="mt-8 grid gap-4 sm:grid-cols-3">

            <div className="rounded-2xl bg-slate-50 p-5">
              <p className="text-sm text-slate-500">
                Account
              </p>
              <p className="mt-1 font-semibold">
                Active
              </p>
            </div>

            <div className="rounded-2xl bg-slate-50 p-5">
              <p className="text-sm text-slate-500">
                Email
              </p>
              <p className="mt-1 font-semibold">
                {user.emailVerified ? "Verified" : "Unverified"}
              </p>
            </div>

            <div className="rounded-2xl bg-slate-50 p-5">
              <p className="text-sm text-slate-500">
                Provider
              </p>
              <p className="mt-1 font-semibold">
                {user.providerData[0]?.providerId ===
                "google.com"
                  ? "Google"
                  : "Email"}
              </p>
            </div>

          </div>

          <button
            onClick={handleSignOut}
            className="mt-8 rounded-full bg-slate-900 px-6 py-3 font-medium text-white transition hover:bg-slate-800"
          >
            Sign out
          </button>
        </div>
      </div>
    </main>
  );
}